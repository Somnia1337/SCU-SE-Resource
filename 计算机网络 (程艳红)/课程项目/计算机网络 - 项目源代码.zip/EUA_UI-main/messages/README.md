# Protobuf Messages

This folder contains Protobuf message files that serve as an API between Dart and Rust. `.proto` files can be compiled into Dart and Rust code with the command `rinf message`, provided by the [Rinf](https://rinf.cunarist.com) framework.
