use std::collections::VecDeque;
use std::io::{self, Write};

/// 有效的数值字符
const DIGITS: &str = "0123456789.";

/// 有效的运算符
const OPS: &str = "+-*/%^&()=";

/// 运算符的栈内外优先级, 排列顺序与 `OPS` 相同
const RANK: [[u8; 2]; 10] = [
    [3, 2],
    [3, 2],
    [5, 4],
    [5, 4],
    [5, 4],
    [7, 6],
    [7, 6],
    [1, 8],
    [8, 1],
    [0, 0],
];

/// 检查时错误
#[derive(Debug, PartialEq)]
enum ChecktimeError {
    Empty,                // 空输入
    InvalidChar(char),    // 非法字符
    Syntax(char),         // 连续的操作符
    UnmatchedParentheses, // 括号不匹配
    IncorrectEqualSign,   // 等号数量或位置非法
}

/// 计算时错误
#[derive(Debug, PartialEq)]
enum EvaltimeError {
    ValueParse, // 数值解析错误
    Stack,      // 空栈错误
    NoResult,   // 无结果
}

fn main() {
    println!("有效的字符: {}{}", DIGITS, OPS);
    println!("请以 '=' 结尾");
    println!("--------------------");

    'outer: loop {
        let mut stop = false;
        let mut input = String::new();
        while !stop {
            input = read_input("输入表达式: ");
            if input.eq("exit") {
                break 'outer;
            }
            match check(&input) {
                Ok(_) => stop = true,
                Err(e) => {
                    let error_message = match e {
                        ChecktimeError::Empty => String::from("输入为空"),
                        ChecktimeError::InvalidChar(c) => format!("非法字符 '{}'", c),
                        ChecktimeError::Syntax(c) => format!("连续的操作符 '{}'", c),
                        ChecktimeError::UnmatchedParentheses => String::from("括号不匹配"),
                        ChecktimeError::IncorrectEqualSign => String::from("必须以单个 '=' 结尾"),
                    };
                    println!("非法输入: {}", error_message);
                }
            }
        }
        let result_message = match eval(&input) {
            Ok(v) => format!("计算结果: {}", v),
            Err(e) => {
                let error_message = match e {
                    EvaltimeError::ValueParse => String::from("数值解析失败"),
                    EvaltimeError::Stack => String::from("操作数不足或空栈错误"),
                    EvaltimeError::NoResult => String::from("结果解析失败"),
                };
                format!("计算错误: {}", error_message)
            }
        };
        println!("{}", result_message);
        println!("--------------------");
    }
}

/// 检查表达式在形式上的有效性
fn check(s: &str) -> Result<(), ChecktimeError> {
    // 空输入
    if s.is_empty() {
        return Err(ChecktimeError::Empty);
    }

    let s_vec: Vec<char> = s.chars().collect();

    let mut last_byte_is_op = false;
    for c in s_vec.iter() {
        let c = *c;

        // 非法字符
        if c != ' ' && !DIGITS.contains(c) && !OPS.contains(c) {
            return Err(ChecktimeError::InvalidChar(c));
        }

        // 连续的操作符
        let cur_byte_is_op = OPS.contains(c) && !matches!(c, '(' | ')');
        if last_byte_is_op && cur_byte_is_op {
            return Err(ChecktimeError::Syntax(c));
        }
        last_byte_is_op = cur_byte_is_op;
    }

    // 括号不匹配
    let mut count = 0;
    for c in s_vec.iter() {
        match *c {
            '(' => count += 1,
            ')' => count -= 1,
            _ => {}
        }
        if count < 0 {
            return Err(ChecktimeError::UnmatchedParentheses);
        }
    }
    if count > 0 {
        return Err(ChecktimeError::UnmatchedParentheses);
    }

    // 末尾为 '=' 且只有一个 '='
    if !s.ends_with("=") || s_vec.iter().filter(|c| **c == '=').count() > 1 {
        return Err(ChecktimeError::IncorrectEqualSign);
    }

    Ok(())
}

/// 计算已通过 `check()` 检查的表达式
fn eval(s: &str) -> Result<f64, EvaltimeError> {
    let mut op_stk: VecDeque<char> = VecDeque::new();
    let mut num_stk: VecDeque<f64> = VecDeque::new();
    let s_vec: Vec<char> = s.chars().collect();
    let mut i = 0;

    while i < s_vec.len() {
        let c = s_vec[i];

        if c == ' ' {
            i += 1;
            continue;
        }

        if c.is_ascii_digit() || (c == '-' && (i == 0 || !s_vec[i - 1].is_ascii_digit())) {
            let mut end = i + 1;
            while end < s_vec.len() && DIGITS.contains(s_vec[end]) {
                end += 1;
            }
            let value: f64 = s_vec[i..end]
                .iter()
                .collect::<String>()
                .parse()
                .map_err(|_| EvaltimeError::ValueParse)?;
            num_stk.push_front(value);
            i = end;
        } else {
            loop {
                let rank_out = get_rank_out(c);
                let rank_in = op_stk.front().map_or(-1, |&top| get_rank_in(top));

                match rank_in.cmp(&rank_out) {
                    std::cmp::Ordering::Less => {
                        op_stk.push_front(c);
                        break;
                    }
                    std::cmp::Ordering::Greater => {
                        if let (Some(op), Some(b), Some(a)) =
                            (op_stk.pop_front(), num_stk.pop_front(), num_stk.pop_front())
                        {
                            num_stk.push_front(cal(a, b, op));
                        } else {
                            return Err(EvaltimeError::Stack);
                        }
                    }
                    std::cmp::Ordering::Equal => {
                        op_stk.pop_front();
                        break;
                    }
                }
            }
            i += 1;
        }
    }

    num_stk.pop_front().ok_or(EvaltimeError::NoResult)
}

/// 以 `char` 形式接收操作符, 计算二元表达式
fn cal(a: f64, b: f64, op: char) -> f64 {
    match op {
        '+' => a + b,
        '-' => a - b,
        '*' => a * b,
        '/' => a / b,
        '%' => a % b,
        '^' => a.powf(b),
        '&' => a.powf(1.0 / b),
        _ => unreachable!(),
    }
}

/// 操作符的栈外优先级
fn get_rank_out(op: char) -> i32 {
    RANK[OPS.find(op).unwrap()][1] as i32
}

/// 操作符的栈内优先级
fn get_rank_in(op: char) -> i32 {
    RANK[OPS.find(op).unwrap()][0] as i32
}

/// 打印一条提示词, 然后读取用户输入
fn read_input(prompt: &str) -> String {
    print!("{}", prompt);
    io::stdout().flush().expect("failed to flush stdout");

    let mut input = String::new();
    io::stdin()
        .read_line(&mut input)
        .expect("failed to read input");

    input.trim().to_owned()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn assert_close(result: f64, expected: f64) {
        assert!(
            (result - expected).abs() < 0.0001,
            "Expected {}, but got {}",
            expected,
            result
        );
    }

    #[test]
    fn valid_case_1() {
        let result = eval("3+6=").unwrap();
        assert_close(result, 9.0);
    }

    #[test]
    fn valid_case_2() {
        let result = eval("2.4+17.8=").unwrap();
        assert_close(result, 20.2);
    }

    #[test]
    fn valid_case_3() {
        let result = eval("107.6+13-26.57=").unwrap();
        assert_close(result, 94.03);
    }

    #[test]
    fn valid_case_4() {
        let result = eval("6.2*70.5=").unwrap();
        assert_close(result, 437.1);
    }

    #[test]
    fn valid_case_5() {
        let result = eval("104.2/23.78=").unwrap();
        assert_close(result, 4.3818);
    }

    #[test]
    fn valid_case_6() {
        let result = eval("4/5=").unwrap();
        assert_close(result, 0.8);
    }

    #[test]
    fn valid_case_7() {
        let result = eval("20^3=").unwrap();
        assert_close(result, 8000.0);
    }

    #[test]
    fn valid_case_8() {
        let result = eval("12.4^3=").unwrap();
        assert_close(result, 1906.624);
    }

    #[test]
    fn valid_case_9() {
        let result = eval("5.6&3=").unwrap();
        assert_close(result, 1.7758);
    }

    #[test]
    fn valid_case_10() {
        let result = eval("37%4=").unwrap();
        assert_close(result, 1.0);
    }

    #[test]
    fn valid_case_11() {
        let result = eval("37.5%12=").unwrap();
        assert_close(result, 1.5);
    }

    #[test]
    fn valid_case_12() {
        let result = eval("6.2*70.5/18.3=").unwrap();
        assert_close(result, 23.8852);
    }

    #[test]
    fn valid_case_13() {
        let result = eval("14.2+5^3=").unwrap();
        assert_close(result, 139.2);
    }

    #[test]
    fn valid_case_14() {
        let result = eval("14.2+27.5*5^3=").unwrap();
        assert_close(result, 3451.7);
    }

    #[test]
    fn valid_case_15() {
        let result = eval("-32.76+(8-5)^2*102.67/(8%3)=").unwrap();
        assert_close(result, 429.255);
    }

    #[test]
    fn valid_case_16() {
        let result = eval("-3.89*(18-2.0)&2+1023.6^3%4=").unwrap();
        assert_close(result, -15.30399);
    }

    #[test]
    fn valid_case_17() {
        let result = eval("-32.76+102.67*78.934/(8.2-5.3)^2=").unwrap();
        assert_close(result, 930.87302);
    }

    #[test]
    fn valid_case_18() {
        let result = eval("-3*((121.35-0.35)&2)/34.567+102.36^(6/9)=").unwrap();
        assert_close(result, 20.92732);
    }

    #[test]
    fn check_empty_input() {
        let result = check("");
        assert_eq!(result, Err(ChecktimeError::Empty));
    }

    #[test]
    fn check_invalid_character() {
        let result = check("3*x=");
        assert_eq!(result, Err(ChecktimeError::InvalidChar('x')));
    }

    #[test]
    fn check_invalid_syntax() {
        let result = check("1+3**5=");
        assert_eq!(result, Err(ChecktimeError::Syntax('*')));
    }

    #[test]
    fn check_parentheses_not_matching_1() {
        let result = check("((1+3)*2=");
        assert_eq!(result, Err(ChecktimeError::UnmatchedParentheses));
    }

    #[test]
    fn check_parentheses_not_matching_2() {
        let result = check("(1+3))*2=");
        assert_eq!(result, Err(ChecktimeError::UnmatchedParentheses));
    }

    #[test]
    fn check_invalid_ending() {
        let result = check("1*3+5");
        assert_eq!(result, Err(ChecktimeError::IncorrectEqualSign));
    }

    #[test]
    fn run_parse_error() {
        let result = eval("1.2.3+4=");
        assert_eq!(result, Err(EvaltimeError::ValueParse));
    }

    #[test]
    fn run_stack_error() {
        let result = eval("3*(*())=");
        assert_eq!(result, Err(EvaltimeError::Stack));
    }

    #[test]
    fn run_no_value_error() {
        let result = eval("=");
        assert_eq!(result, Err(EvaltimeError::NoResult));
    }
}
